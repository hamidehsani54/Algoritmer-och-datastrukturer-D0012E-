import random

class Graph(object): 
    '''
    This class creates, stores and prints a Graph.
    '''
    def __init__(self, nodes):
        '''
        Initialization section of class, here results are stored and are used when output is requested.
        '''
        self.nodes = nodes
        self.choice = self.nodes[:]
        self.edges = []
        self.adjlist = []
        v= len(self.nodes)
        self.matrix = [[0]*v for i in range(v)] #O(n)


    def addRandomEdge(self):   
        '''
        A function that connects nodes randomly, starting from the first node, removing it from a list of not yet visited
        nodes, and then connecting it to one of the remaining nodes that are not yet connected.
        This will be weighted towards the last items in the list due to probability, but this does not
        negatively impact the result since the task is only to generate a connected graph based on the nodes, 
        which this algorithm accomplishes. It then assigns random weights to these generated edges.
        '''
        for node in self.nodes:                                 #O(n)
            if node < len(self.nodes):
                self.choice.remove(node)                        #c
                randomNode = random.sample(self.choice, 1)
                randomNode.append(node)
                randomNode.sort()                               #O(n * log n)
                randomNode.append(random.randint(1,9))
                self.edges.append(randomNode)
        #T = n(O(1) + O(1) + O(1) + O(1) + O(1) + O(1)) + (n * O(n * log n)) = n(c1) * (n *  O(n * log n)) = O(n * n * log n)
        #T = O(n * n * log n)

    def addEdge(self,node, u, w):
        '''
        A small function that manually adds an edge in the list for edges. ["node", "conencted to", "weight"]
        '''
        check = True
        for edges in self.edges:
            if node == u: 
                check = False
                print("Cant connect node to itself")
                break
            if edges[0:2] == [node, u] or edges[0:2] == [u, node]:
                print("Connection already exists, cant add edge")
                check = False
                break
        if check == True: 
            self.edges.append([node, u, w])
        #T = O(n)

    def calculateList(self):
        '''
        A function that calculates an adjacency list based on the edges generated in AddRandomEdge, along with calculating the matrix.
        '''
        for node in self.nodes:
            self.adjlist.append(node)                       #add the node as integer to list
            tempList2 = []                                  
            for edges in self.edges:                
                for connection in range(len(edges)-1):      
                    if node == edges[connection]:           #loop through each item in 2-d list, if there is a connection:
                        tempList = edges[:]                 #copy the edges[connection] item, remove the node element node from it
                        tempList.remove(node)               #then append it to tempList2
                        tempList2.append(tempList[:])   
                        if node-1 != edges[1]-1:                            #extra statement needed for matrix
                            self.matrix[edges[1]-1][node-1] = edges[2]      #store values in self.matrix       
                            self.matrix[node-1][edges[1]-1] = edges[2]  
            self.adjlist.append(tempList2)                  #final tempList2 added to self.adjlist and then reset for each node
            
    #T = O(n^3)       

    def adjacencyMatrix(self):
        '''
        Print function for adjacency Matrix.
        '''
        r = len(self.nodes)
        c =len(self.nodes)
        for i in range(r):
            for j in range(c):
                print(self.matrix[i][j], end=" ")
            print("")
    #T = O(n^2) 
    def adjacencyList(self):
        '''
        Print function for adjacency List.
        '''
        for item in self.adjlist:
            if isinstance(item, list):
                for lists in item:
                    print(" --> ", "[" + str(lists[0]) + "]", " (weight: " + str(lists[1]) + " )")
            else:
                print("Node", "["+ str(item) +"]:")
    #T = O(n^2)

def main():
    nodes = [1,2,3,4,5]                          #Assign number of nodes, [0 to N]. USE INTEGERS > 0.
    graph = Graph(nodes)                                    #Create Graph object

    #Default
    graph.addRandomEdge()                                   #Generate edges for given nodes
    graph.calculateList()                                   #Calculations for the list outputs (matrix, adjacency list)
    print("Edges: (node, node connected to, weight)")       #
    for edges in graph.edges:                               #      Outputs
        print(edges)                                        #
    print("Adjacency List:")                                #
    graph.adjacencyList()                                   #
    print("Matrix:")
    graph.adjacencyMatrix()                                 #


'''
    #Manual Section
    
    graph.addRandomEdge()
    graph.addEdge(4,2,5)
    print("Edges: (node, node connected to, weight)")
    for edges in graph.edges:
        print(edges)
    graph.calculateList()                               
    print("Adjacency List:")
    graph.adjacencyList()
    print("Matrix: ")
    graph.adjacencyMatrix()
    print("Nodes: \n", graph.nodes)                         
    print("Edges: (node, node connected to, weight)")
'''

main()

#Time complexity = O(n^3)  (Tripple nested forloop in calculate_list)
#Space complexity = O(n^2) (Two dimentional array "self.matrix")

'''
    Time complexity / Space complexity:

    Efter att ha räknat ut big oh för varje funktion i klassen så kom vi fram till 
    att big oh notation av koden är O(n^3) eftersom att den kommer att växa mest med n. 
    Detta är väldigt dåligt för en algoritm, men n^3 beror på våran tre nestade for-loop. 
    Big oh för varje funktion finns kommenterad i koden. Eftersom att vi använder oss utav 
    en tvådimensionell array för lagra våran matrix så kommer space complexity att vara O(n^2).
'''