import math
import sys

def maxProduct(arr, l, m, h) : 
    #https://www.geeksforgeeks.org/maximum-subarray-sum-using-divide-and-conquer-algorithm/ MODIFIED THIS
    #Help function used for maxSubArrayProduct
    currentProduct = 1; minLeftProduct= minRightProduct = 0; leftProduct = -sys.maxsize          # Include elements on left of mid.

    for i in range(m, l-1, -1):                             #from middle to left side, "-1 increment"
        currentProduct = currentProduct * arr[i]            #check currentProduct
        if (currentProduct > leftProduct):                  #if currentproduct > leftProduct (largest product on left side)-> update
            leftProduct = currentProduct 
        elif (currentProduct < minLeftProduct):
            minLeftProduct = currentProduct

    currentProduct = 1; rightProduct = -sys.maxsize         #Do the same for the right side, look for largest product
    for i in range(m + 1, h + 1) :                          
        currentProduct = currentProduct * arr[i] 
        if (currentProduct > rightProduct) : 
            rightProduct = currentProduct 
        elif (currentProduct < minRightProduct):
            minRightProduct = currentProduct

    return max(minLeftProduct * minRightProduct, leftProduct *  rightProduct, leftProduct, rightProduct)    #Return largest product

def maxSubArrayProduct(arr, l, h):                          #Returns the maximum product of the subarrays of arr[l..h] 
    if (l == h) :                                           #Base Case: Only one element left in arr
        return arr[l]
    m = (l + h) // 2                                        #Divide the problem into two subproblems

    return max(maxSubArrayProduct(arr, l, m),               #Recursively find largest product for left and right side (divide and conquer)
               maxSubArrayProduct(arr, m+1, h), 
               maxProduct(arr, l, m, h)) 

def kadanesRec(arr, maxProduct, currentProduct):
    #modified Kadanes algorithm to be recursive and work for products instead of sums of subarrays

    if not arr:                                                 #base case: recursively loop untill array is empty
        return maxProduct
    
    if currentProduct * arr[0] < 1:                             #If all inputs are < 1: take largest float 
        currentProduct = currentProduct * arr[0]                #currentProduct must be init to 1 for multiplication to work
    if arr[0] > currentProduct and currentProduct < 1:          #This statement is needed in case a larger value comes after a smaller one, i.e. [..., 2, 15, ...]
        currentProduct = arr[0]                             
    else:
        currentProduct = currentProduct * arr[0]                #always: currentproduct = currentproduct * arr[0]
    maxProduct = max(currentProduct, maxProduct)                #update maxProduct
    return kadanesRec(arr[1:], maxProduct, currentProduct)      #recursive "for-loop" (remove first element in each recursion since its already been compared)

def main():
    arr = [5,7,7,7,-10]               #2^n elements in list, non zero with negative numbers used in question 1.
    #arr = [2.3, 6.12, 2.5, 7.3, 0.75, 0.12, 0.62, 0.18]        #2^n elements in list, non zero with only positive numbers used for question 2.

    if min(arr) < 0:                                            #If there are negative values in array: Use the O(n log n) divide and conquer function
        n = len(arr) 
        print("(Q1) Maximum contiguous product is:", maxSubArrayProduct(arr, 0, n-1))
    elif min(arr) > 0:                                          #Else if all numbers are non zero and positive: Use the linear recursive iterative function O(n)
        print("(Q2) Maximum contigous product is:", kadanesRec(arr, 0, 1))
main()